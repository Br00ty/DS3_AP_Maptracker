# Custom items via Lua API

This custom item is using an example from the [Evermizer tracker pack](https://github.com/Cyb3RGER/evermizer-tracker-package)

It creates and extend version of a ``progressive_toggle`` item

``class.lua`` allows you to create "classes" in lua

``progressiveTogglePlusWrapper.lua`` creates the wrapper class that has all need funtion to communicate with PopTracker

``progressiveTogglePlus.lua`` create the actuall class

more info soon